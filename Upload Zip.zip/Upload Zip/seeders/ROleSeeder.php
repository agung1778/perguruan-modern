<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;

class RoleSeeder extends Seeder
{
    public function run(): void
    {
        Role::create([
            'name'=>'Super Admin'
        ]);

        Role::create([
            'name'=>'Admin Perguruan'
        ]);

        Role::create([
            'name'=>'Operator Sekolah'
        ]);
    }
}