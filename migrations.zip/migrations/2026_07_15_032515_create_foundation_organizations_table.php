<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('foundation_organizations', function(Blueprint $table){
            $table->uuid('id')->primary();
            $table->string('name');
            $table->string('photo')
            ->nullable();
            $table->string('position');
            $table->integer('order')
            ->default(0);
            $table->boolean('is_active')
            ->default(true);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('foundation_organizations');
    }
};
