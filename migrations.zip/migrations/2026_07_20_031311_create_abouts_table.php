<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('abouts', function (Blueprint $table) {

            $table->id();

            $table->string('title');

            $table->text('description');

            $table->longText('history')
                ->nullable();

            $table->text('vision')
                ->nullable();

            $table->longText('mission')
                ->nullable();

            $table->string('image')
                ->nullable();

            $table->year('established')
                ->nullable();

            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('abouts');
    }
};
