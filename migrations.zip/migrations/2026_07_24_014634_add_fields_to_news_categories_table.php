<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('news_categories', function (Blueprint $table) {
            $table->string('slug')
                ->nullable()
                ->after('name');

            $table->text('description')
                ->nullable()
                ->after('slug');

            $table->boolean('is_active')
                ->default(true)
                ->after('description');
        });
    }

    public function down(): void
    {
        Schema::table('news_categories', function (Blueprint $table) {
            $table->dropColumn([
                'slug',
                'description',
                'is_active',
            ]);
        });
    }
};