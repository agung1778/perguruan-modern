<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('student_data', function (Blueprint $table) {
            $table->uuid('id')->change();
        });
    }

    public function down(): void
    {
        Schema::table('student_data', function (Blueprint $table) {
            $table->unsignedBigInteger('id')->change();
        });
    }
};